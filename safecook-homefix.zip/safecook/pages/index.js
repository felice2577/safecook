export default function Home() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>🍳 Benvenuto su SafeCook</h1>
      <p>Questa è la tua app di cucina interattiva!</p>
    </div>
  );
}
